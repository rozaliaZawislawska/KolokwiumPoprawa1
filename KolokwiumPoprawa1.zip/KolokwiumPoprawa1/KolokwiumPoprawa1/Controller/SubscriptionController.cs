﻿using KolokwiumPoprawa1.Models;
using KolokwiumPoprawa1.Models.Dto;
using KolokwiumPoprawa1.Repository;
using Microsoft.AspNetCore.Mvc;

namespace KolokwiumPoprawa1.Controller;


[Route("api/students")]
[ApiController]
public class SubscriptionController: ControllerBase
{
    public readonly ISubscriprionRepository _subscriprionRepository;
    public readonly IServiceRepository _serviceRepository;
    public readonly ICommitmentRepository _commitmentRepository;
    public readonly IUserRepository _userRepository;
    

    public SubscriptionController(IUserRepository userRepository, ISubscriprionRepository subscriprionRepository, IServiceRepository serviceRepository, ICommitmentRepository commitmentRepository)
    {
        _subscriprionRepository = subscriprionRepository;
        _serviceRepository = serviceRepository;
        _commitmentRepository = commitmentRepository;
        _userRepository = userRepository;
    }
    
    [HttpGet("commitment")]
    public IActionResult GetCommitment(int IdUser )
    {
        var resultList = new List<CommitmentDto>(); 
        var subscriptions = _subscriprionRepository.GetSubscription(IdUser);
        foreach (var subscription in subscriptions)
        {
            var service = _serviceRepository.GetService(subscription.IdService);
            var commitment = _commitmentRepository.GetCommitment(subscription.IdSubscription);
            var result = new CommitmentDto
            {
                IdSubscription = subscription.IdSubscription,
                service = service,
                commitments = commitment
            };
            resultList.Add(result);
        }
        return Ok(resultList);
    }
    
    [HttpPost("subscription")]
    public IActionResult CreateTask([FromBody] CreateSubscriprionDto subscriptionDto)
    {
        if(!(subscriptionDto.leftToPay>=0))
            return StatusCode(457, "Incorrect value leftToPay");
        if(!_userRepository.UserExist(subscriptionDto.IdUser))
            return StatusCode(404, "User doen't exists");
        if(!_serviceRepository.ServiceExist(subscriptionDto.IdService))
            return StatusCode(404, "Service doen't exists");
        if(!_subscriprionRepository.HasSubscription(subscriptionDto.IdUser, subscriptionDto.IdService))
            return StatusCode(457, "Already has subscription");
        var subscriptionCreate = _subscriprionRepository.CreateSubscription(subscriptionDto);
        var subscriprion = _subscriprionRepository.GetSubscription(
            subscriptionDto.IdUser, subscriptionDto.IdService);
        var commitment = _commitmentRepository.CreateCommitment(subscriptionDto, subscriprion.IdSubscription);
        if (subscriptionCreate == 1 && commitment ==1)
            return Ok(StatusCodes.Status201Created);
        else
            return Conflict();
    }
    
    
}