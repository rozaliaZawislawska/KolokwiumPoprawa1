﻿using System.ComponentModel.DataAnnotations;

namespace KolokwiumPoprawa1.Models;

public class Commitment
{
    [Required]
    public int IdCommitment { get; set; }
    public DateTime PaymentDeadline { get; set; }
    public float LeftToPay { get; set; }
}