﻿using System.ComponentModel.DataAnnotations;

namespace KolokwiumPoprawa1.Models;

public class User
{
    [Required]
    public int IdUser { get; set; }
}