﻿using System.ComponentModel.DataAnnotations;

namespace KolokwiumPoprawa1.Models;

public class Subscription
{
    [Required]
    public int IdSubscription { get; set; }
    public int IdUser { get; set; }
    public int IdService { get; set; }
}