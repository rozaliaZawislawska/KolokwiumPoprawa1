﻿namespace KolokwiumPoprawa1.Models.Dto;

public class CommitmentDto
{
    public int IdSubscription { get; set; }
    public Service service { get; set; }
    public IEnumerable<Commitment> commitments { get; set; }
    
}