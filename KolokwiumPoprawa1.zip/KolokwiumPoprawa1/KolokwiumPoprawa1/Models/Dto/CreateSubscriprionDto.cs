﻿namespace KolokwiumPoprawa1.Models.Dto;

public class CreateSubscriprionDto
{
    public int IdUser { get; set; }
    public int IdService { get; set; }
    public float leftToPay { get; set; }
}