﻿using System.ComponentModel.DataAnnotations;

namespace KolokwiumPoprawa1.Models;

public class Service
{
    [MaxLength(200)]
    public string Name { get; set; }
    public int IdService { get; set; }
}