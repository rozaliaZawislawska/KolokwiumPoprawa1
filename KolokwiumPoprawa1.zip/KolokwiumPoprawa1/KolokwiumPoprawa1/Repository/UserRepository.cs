﻿using System.Data.SqlClient;

namespace KolokwiumPoprawa1.Repository;

public interface IUserRepository
{
    public bool UserExist(int IdUser);
}

public class UserRepository: IUserRepository
{
    public readonly IConfiguration _configuration;

    public UserRepository(IConfiguration configuration)
    {
        _configuration = configuration;
    }
    
    public bool UserExist(int IdUser)
    {
        using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
        con.Open();

        using var cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText =
            "SELECT IdUser FROM Service WHERE IdUser = @IdUser";
        cmd.Parameters.AddWithValue("@IdUser", IdUser);  
        
        var dr = cmd.ExecuteReader();
        dr.Read();

        return dr.HasRows;
    }
}