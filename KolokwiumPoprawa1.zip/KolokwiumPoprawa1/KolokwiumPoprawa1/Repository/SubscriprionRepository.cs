﻿using System.Data.SqlClient;
using KolokwiumPoprawa1.Models;
using KolokwiumPoprawa1.Models.Dto;

namespace KolokwiumPoprawa1.Repository;

public interface ISubscriprionRepository
{
    public IEnumerable<Subscription> GetSubscription(int IdUser);
    public Subscription GetSubscription(int IdUser, int IdService);
    public int CreateSubscription(CreateSubscriprionDto subscriprionDto);
    public bool HasSubscription(int IdUser, int IdService);
}

public class SubscriprionRepository: ISubscriprionRepository
{
    public readonly IConfiguration _configuration;

    public SubscriprionRepository(IConfiguration configuration)
    {
        _configuration = configuration;
    }


    public IEnumerable<Subscription> GetSubscription(int IdUser)
    {
        using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
        con.Open();

        using var cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText =
            "SELECT IdSubscription, IdUser, IdService  FROM Subscription WHERE IdUser = @IdUser";
        cmd.Parameters.AddWithValue("@IdUser", IdUser);  
        
        var subscriptionList = new List<Subscription>();
        var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            var subscription = new Subscription()
            {
                IdSubscription = (int)dr["IdSubscription"],
                IdUser = (int)dr["IdUser"],
                IdService = (int)dr["IdService"]
            };
            subscriptionList.Add(subscription);
        }
        return subscriptionList;
    }

    public int CreateSubscription(CreateSubscriprionDto subscriprionDto)
    {
        using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
        con.Open();

        using var cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText =
            "INSERT INTO Subscription (IdUser, IdService)" +
            "VALUES (@IdUser, @IdService);";
        cmd.Parameters.AddWithValue("@IdUser", subscriprionDto.IdUser); 
        cmd.Parameters.AddWithValue("@IdService", subscriprionDto.IdService); 
        
        var affectedRows = cmd.ExecuteNonQuery();
        return affectedRows;
    }
    
    public Subscription GetSubscription(int IdUser, int IdService)
    {
        using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
        con.Open();

        using var cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText =
            "SELECT IdSubscription  FROM Subscription WHERE IdUser = @IdUser AND IdService = @IdService";
        cmd.Parameters.AddWithValue("@IdUser", IdUser);  
        cmd.Parameters.AddWithValue("@IdService", IdService);  
        
        var dr = cmd.ExecuteReader();
        dr.Read();
        var subscription = new Subscription()
        {
            IdSubscription = (int)dr["IdSubscription"],
            IdUser = (int)dr["IdUser"],
            IdService = (int)dr["IdService"]
        };
        
        
        return subscription;
    }
    
    public bool HasSubscription(int IdUser, int IdService)
    {
        using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
        con.Open();

        using var cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText =
            "SELECT IdSubscription  FROM Subscription WHERE IdUser = @IdUser AND IdService = @IdService";
        cmd.Parameters.AddWithValue("@IdUser", IdUser);  
        cmd.Parameters.AddWithValue("@IdService", IdService);  
        
        var dr = cmd.ExecuteReader();
        dr.Read();
        
        
        return dr.HasRows;
    }
}