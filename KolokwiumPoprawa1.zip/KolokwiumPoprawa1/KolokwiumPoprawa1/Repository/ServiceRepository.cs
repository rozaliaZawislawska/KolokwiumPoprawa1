﻿using System.Data.SqlClient;
using KolokwiumPoprawa1.Models;

namespace KolokwiumPoprawa1.Repository;

public interface IServiceRepository
{
    public Service GetService(int IdService);
    public bool ServiceExist(int IdService);
}

public class ServiceRepository: IServiceRepository
{
    public readonly IConfiguration _configuration;
    private IServiceRepository _serviceRepositoryImplementation;

    public ServiceRepository(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public Service GetService(int IdService)
    {
        using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
        con.Open();

        using var cmd = new SqlCommand();
        cmd.Connection = con;
        
        cmd.CommandText =
            "SELECT Name, IdService  FROM Service WHERE IdService = @IdService ORDER BY PaymentDeadline";
        cmd.Parameters.AddWithValue("@IdService", IdService);
        
        
        
        var dr = cmd.ExecuteReader();
        dr.Read();
        var service = new Service()
        {
            Name = dr["Name"].ToString(),
            IdService = (int)dr["IdService"]
        };
        
    
        return service;
    }



    public bool ServiceExist(int IdService)
    {
        using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
        con.Open();

        using var cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText =
            "SELECT Name, IdService  FROM Service WHERE IdService = @IdService";
        cmd.Parameters.AddWithValue("@IdService", IdService);  
        
        var dr = cmd.ExecuteReader();
        dr.Read();


        return dr.HasRows;
    }
}