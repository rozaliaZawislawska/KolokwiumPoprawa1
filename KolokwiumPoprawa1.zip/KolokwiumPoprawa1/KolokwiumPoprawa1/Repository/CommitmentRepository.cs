﻿using System.Data.SqlClient;
using KolokwiumPoprawa1.Models;
using KolokwiumPoprawa1.Models.Dto;

namespace KolokwiumPoprawa1.Repository;

public interface ICommitmentRepository
{
    public IEnumerable<Commitment> GetCommitment(int IdSubscription);
    public int CreateCommitment(CreateSubscriprionDto subscriprionDto, int IdSubscription);
    
}

public class CommitmentRepository: ICommitmentRepository
{
    public readonly IConfiguration _configuration;

    public CommitmentRepository(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public IEnumerable<Commitment> GetCommitment(int IdSubscription)
    {
        using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
        con.Open();

        using var cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText =
            "SELECT IdCommitment, PaymentDeadline, LeftToPay  FROM Service WHERE IdSubscription = @IdSubscription";
        cmd.Parameters.AddWithValue("@IdSubscription", IdSubscription);  
        
        var commitmentList = new List<Commitment>();
        var dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            var commitment = new Commitment()
            {
                IdCommitment = (int)dr["IdCommitment"],
                PaymentDeadline = (DateTime)dr["PaymentDeadline"],
                LeftToPay = (float)dr["LeftToPay"]
            };
        }
        return commitmentList;
    }
    
    public int CreateCommitment(CreateSubscriprionDto subscriprionDto, int IdSubscription)
    {
        using var con = new SqlConnection(_configuration["ConnectionStrings:DefaultConnection"]);
        con.Open();

        using var cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText =
            "INSERT INTO Commitment (PaymentDeadline, LeftToPay, IdSubscription )" +
            "VALUES (@PaymentDeadline, @LeftToPay, @IdSubscription);";
        cmd.Parameters.AddWithValue("@PaymentDeadline", DateTime.Today.AddDays(7)); 
        cmd.Parameters.AddWithValue("@LeftToPay", subscriprionDto.leftToPay); 
        cmd.Parameters.AddWithValue("@IdSubscription", IdSubscription);
        
        var affectedRows = cmd.ExecuteNonQuery();
        return affectedRows;
    }
}